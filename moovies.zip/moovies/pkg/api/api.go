package api

type Movie struct {
	Title string `json:"title"`
	Year  string `json:"year"`
	Rate  string `json:"rate"`
}
